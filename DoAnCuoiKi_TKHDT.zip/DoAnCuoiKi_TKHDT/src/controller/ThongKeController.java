package controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import com.toedter.calendar.JDateChooser;
import java.util.Date;

public class ThongKeController {
    private JPanel tablePanel;
    private JLabel bestSellingMenuLabel;
    private JLabel totalCustomersLabel;
    private JLabel totalRevenueLabel;
    private JDateChooser dateChooser;
    private JComboBox<String> monthComboBox;
    private JTextField monthYearField;
    private JComboBox<String> yearComboBox;

    public ThongKeController(JPanel tablePanel, JLabel bestSellingMenuLabel, JLabel totalCustomersLabel, JLabel totalRevenueLabel, 
                             JDateChooser dateChooser, JComboBox<String> monthComboBox, JTextField monthYearField, JComboBox<String> yearComboBox) {
        this.tablePanel = tablePanel;
        this.bestSellingMenuLabel = bestSellingMenuLabel;
        this.totalCustomersLabel = totalCustomersLabel;
        this.totalRevenueLabel = totalRevenueLabel;
        this.dateChooser = dateChooser;
        this.monthComboBox = monthComboBox;
        this.monthYearField = monthYearField;
        this.yearComboBox = yearComboBox;
    }

    public void addShowTableButtonListener(JButton showTableButton) {
        showTableButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Thực hiện logic để cập nhật bảng thống kê
                updateStatistics();
                tablePanel.setVisible(true);
            }
        });
    }

    private void updateStatistics() {
        // Lấy dữ liệu từ các tiêu chí
        Date selectedDate = dateChooser.getDate();
        String selectedMonth = (String) monthComboBox.getSelectedItem();
        String selectedMonthYear = monthYearField.getText();
        String selectedYear = (String) yearComboBox.getSelectedItem();

        // Thực hiện các logic cập nhật thông tin thống kê dựa trên tiêu chí
        // Ví dụ dưới đây chỉ là giả định. Bạn cần thay thế bằng mã thực tế để lấy dữ liệu từ cơ sở dữ liệu hoặc nguồn dữ liệu khác.

        if (selectedDate != null) {
            // Thống kê theo ngày
            String bestSellingMenu = "Phở bò (theo ngày)";
            String totalCustomers = "20 khách (theo ngày)";
            String totalRevenue = "1,000,000 VND (theo ngày)";
            updateLabels(bestSellingMenu, totalCustomers, totalRevenue);
        } else if (selectedMonth != null && !selectedMonthYear.isEmpty()) {
            // Thống kê theo tháng và năm
            String bestSellingMenu = "Phở bò (theo tháng)";
            String totalCustomers = "200 khách (theo tháng)";
            String totalRevenue = "10,000,000 VND (theo tháng)";
            updateLabels(bestSellingMenu, totalCustomers, totalRevenue);
        } else if (selectedYear != null) {
            // Thống kê theo năm
            String bestSellingMenu = "Phở bò (theo năm)";
            String totalCustomers = "2000 khách (theo năm)";
            String totalRevenue = "100,000,000 VND (theo năm)";
            updateLabels(bestSellingMenu, totalCustomers, totalRevenue);
        }
    }

    private void updateLabels(String bestSellingMenu, String totalCustomers, String totalRevenue) {
        bestSellingMenuLabel.setText("Món ăn bán nhiều nhất: " + bestSellingMenu);
        totalCustomersLabel.setText("Ngày bán được nhiều nhất: " + totalCustomers);
        totalRevenueLabel.setText("Tổng doanh thu: " + totalRevenue);
    }
}

package model;

public interface ObserverKM {
    void updateKM(String tenCongTy, String noidungchuongtrinh);
}

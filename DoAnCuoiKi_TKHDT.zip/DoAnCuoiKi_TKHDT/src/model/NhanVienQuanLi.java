package model;

import java.util.ArrayList;

public class NhanVienQuanLi extends NhanVien {

	public NhanVienQuanLi(String maNV) {
		super(maNV);
	}

	public void themMonAn(String maMon, String tenMon, double gia) {
		MonAn m = new MonAn(maMon, tenMon, gia);
		if (!super.getDsMonAn().contains(m)) {
			super.getDsMonAn().add(m);
		}
	}

}

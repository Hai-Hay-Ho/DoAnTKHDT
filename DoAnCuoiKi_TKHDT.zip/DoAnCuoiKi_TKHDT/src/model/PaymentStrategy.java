package model;
public interface PaymentStrategy  {
    double calculateTotal(double amount);
}
